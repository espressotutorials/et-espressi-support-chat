import * as i0 from "@angular/core";
import { ElementRef, InjectionToken, OnChanges, Provider, SimpleChanges } from "@angular/core";
import { Observable } from "rxjs";
import * as i1 from "@angular/common";
import * as i2 from "@angular/common/http";
import * as i3 from "@angular/forms";
export type SupportLanguage = 'de' | 'en' | 'fr' | 'es' | 'pt' | 'ja';
export interface SupportChatConfig {
  apiBaseUrl: string;
  platform: string;
  vectorStoreId: string;
  language: SupportLanguage;
  userId?: string | null;
  email?: string | null;
  requestId?: string | null;
  product?: string;
  privacyUrl?: string;
  supportUrl?: string;
  theme?: {
    accentColor?: string;
    position?: 'right' | 'left';
    zIndex?: number;
  };
  /** Stable per embedding when multiple instances on one page need independent restoration. */
  instanceId?: string;
}
export interface PageContext {
  pagePath: string;
}
export interface SessionCreateRequest {
  platform: string;
  vectorStoreId: string;
  language: SupportLanguage;
  userId?: string;
  email?: string;
  pageContext?: PageContext;
}
export interface SupportSession {
  chatId: string;
  sessionToken: string;
  contactStatus?: string;
  platform: string;
  language: SupportLanguage;
  expiresAt: string;
}
export interface SupportSource {
  title?: string;
  url?: string;
  excerpt?: string;
  fileId?: string;
}
export interface ChatMessageRequest {
  clientMessageId: string;
  message: string;
}
export interface ChatMessageResponse {
  messageId: string;
  clientMessageId?: string;
  answer?: string;
  message?: string;
  sources?: SupportSource[];
  resolutionPrompt?: boolean;
  needsHumanSupport?: boolean;
  status?: string;
  createdAt?: string;
}
export interface ResolutionRequest {
  resolved: boolean;
  messageId?: string;
}
export interface FeedbackRequest {
  rating: 'positive' | 'negative';
  comment?: string;
}
export interface TicketEnvironment {
  platform: string;
  system: string;
  browser_user: string;
  mobile: boolean;
  connection?: string;
  url: string;
  product?: string;
}
export interface TicketRequest {
  requestId?: string;
  environment: TicketEnvironment;
}
export interface TicketResponse {
  status: 'submitted' | 'unknown' | 'failed';
  ticketId?: string;
}
export interface ApiErrorBody {
  code?: string;
  message?: string;
}
export declare class SupportChatApiError extends Error {
  readonly status: number;
  readonly code: string;
  constructor(status: number, code: string, message: string);
}
export declare const ESPRESSO_SUPPORT_CHAT_CONFIG: InjectionToken<SupportChatConfig>;
export declare function provideEspressoSupportChat(config: SupportChatConfig): Provider;
export declare class SupportChatApiService {
  private readonly http;
  private readonly config;
  private readonly destroyRef;
  private readonly cancelRequests;
  private get base();
  createSession(body: SessionCreateRequest): Observable<SupportSession>;
  getSession(chatId: string, token: string): Observable<SupportSession>;
  addContact(chatId: string, email: string, token: string): Observable<unknown>;
  sendMessage(chatId: string, body: ChatMessageRequest, token: string): Observable<ChatMessageResponse>;
  resolution(chatId: string, body: ResolutionRequest, token: string): Observable<unknown>;
  feedback(chatId: string, body: FeedbackRequest, token: string): Observable<unknown>;
  close(chatId: string, token: string): Observable<unknown>;
  ticket(chatId: string, body: TicketRequest, token: string): Observable<TicketResponse>;
  cancelPending(): void;
  private headers;
  private request;
  static ɵfac: i0.ɵɵFactoryDeclaration<SupportChatApiService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
declare class EnvironmentCollectorService {
  collect(config: SupportChatConfig): {
    platform: string;
    system: string;
    browser_user: string;
    mobile: boolean;
    connection?: string;
    url: string;
    product?: string;
  };
  static ɵfac: i0.ɵɵFactoryDeclaration<EnvironmentCollectorService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
declare class SupportChatSessionService {
  private readonly config;
  private readonly api;
  private active?;
  private cachedEmail?;
  private readonly volatileInstance;
  private key;
  private emailKey;
  cacheEmail(email: string): void;
  getCachedEmail(): string | undefined;
  get(): Promise<SupportSession | undefined>;
  create(email?: string): Promise<SupportSession>;
  invalidate(): void;
  private reset;
  static ɵfac: i0.ɵɵFactoryDeclaration<SupportChatSessionService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export interface ChatStrings {
  title: string;
  welcome: string;
  ai: string;
  privacy: string;
  emailLabel: string;
  emailHint: string;
  emailInvalid: string;
  send: string;
  placeholder: string;
  end: string;
  close: string;
  resolved: string;
  yes: string;
  no: string;
  ticket: string;
  feedback: string;
  comment: string;
  continue: string;
  ticketSuccess: string;
  ticketUnknown: string;
  ticketFailed: string;
  noKnowledge: string;
  genericError: string;
  sensitive: string;
  expired: string;
  rateLimited: string;
  retry: string;
  skip: string;
  loading: string;
  sources: string;
  chatEnded: string;
  newChat: string;
}
/** UI messages supported by the initial release. Other configured languages currently fall back to German. */
export declare function getChatStrings(language: SupportLanguage): ChatStrings;
export declare class SupportChatComponent implements OnChanges {
  apiBaseUrl?: string;
  platform?: string;
  vectorStoreId?: string;
  language?: SupportLanguage;
  userId?: string | null;
  email?: string | null;
  requestId?: string | null;
  product?: string;
  privacyUrl?: string;
  supportUrl?: string;
  instanceId?: string;
  private readonly injectedConfig;
  readonly config: import("@espresso-tutorials/support-chat").SupportChatConfig;
  readonly api: SupportChatApiService;
  readonly sessions: SupportChatSessionService;
  readonly environment: EnvironmentCollectorService;
  readonly element: ElementRef<any>;
  private readonly destroyRef;
  private readonly changeDetector;
  open: boolean;
  closing: boolean;
  busy: boolean;
  started: boolean;
  closed: boolean;
  askEmail: boolean;
  emailDraft: string;
  emailError: string;
  input: string;
  feedbackComment: string;
  error: string;
  ticketState: string;
  messages: Array<{
    role: 'user' | 'assistant';
    text: string;
    result?: ChatMessageResponse;
  }>;
  pendingUserMessage: string;
  private pendingClientMessageId;
  private pendingMessageAdded;
  lastAssistantMessageId?: string;
  showResolution: boolean;
  showFeedback: boolean;
  private identityGeneration;
  private emailCapturedInWidget;
  constructor();
  ngOnChanges(changes: SimpleChanges): void;
  get strings(): ChatStrings;
  show(): Promise<void>;
  minimize(): void;
  onWindowAnimationEnd(event: AnimationEvent): void;
  private restore;
  validEmail(value: string): boolean;
  submitEmail(): Promise<boolean>;
  send(): Promise<void>;
  sendPending(): Promise<void>;
  continueAfterEmail(): Promise<void>;
  resolve(resolved: boolean): Promise<void>;
  createTicket(): Promise<void>;
  continueTicketAfterEmail(): Promise<void>;
  private submitTicket;
  end(rating?: 'positive' | 'negative'): Promise<void>;
  skipFeedback(): Promise<void>;
  startNewChat(): void;
  private finishChat;
  private clearCapturedEmail;
  safeLink(url: string): boolean;
  private uuid;
  static ɵfac: i0.ɵɵFactoryDeclaration<SupportChatComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SupportChatComponent, "et-support-chat", never, {
    "apiBaseUrl": {
      "alias": "apiBaseUrl";
      "required": false;
    };
    "platform": {
      "alias": "platform";
      "required": false;
    };
    "vectorStoreId": {
      "alias": "vectorStoreId";
      "required": false;
    };
    "language": {
      "alias": "language";
      "required": false;
    };
    "userId": {
      "alias": "userId";
      "required": false;
    };
    "email": {
      "alias": "email";
      "required": false;
    };
    "requestId": {
      "alias": "requestId";
      "required": false;
    };
    "product": {
      "alias": "product";
      "required": false;
    };
    "privacyUrl": {
      "alias": "privacyUrl";
      "required": false;
    };
    "supportUrl": {
      "alias": "supportUrl";
      "required": false;
    };
    "instanceId": {
      "alias": "instanceId";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
export declare class SupportChatModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<SupportChatModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<SupportChatModule, never, [typeof i1.CommonModule, typeof i2.HttpClientModule, typeof i3.FormsModule, typeof SupportChatComponent], [typeof SupportChatComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<SupportChatModule>;
}
export {};