import * as i0 from "@angular/core";
import { ChangeDetectorRef, Component, DestroyRef, ElementRef, Injectable, InjectionToken, Input, NgModule, ViewEncapsulation, inject } from "@angular/core";
import { HttpClient, HttpClientModule, HttpHeaders } from "@angular/common/http";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { Subject, catchError, firstValueFrom, takeUntil, throwError } from "rxjs";
import * as i1 from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
var SupportChatApiError = class extends Error {
	status;
	code;
	constructor(status, code, message) {
		super(message);
		this.status = status;
		this.code = code;
		this.name = "SupportChatApiError";
	}
};
const ESPRESSO_SUPPORT_CHAT_CONFIG = new InjectionToken("ESPRESSO_SUPPORT_CHAT_CONFIG");
function provideEspressoSupportChat(config) {
	return {
		provide: ESPRESSO_SUPPORT_CHAT_CONFIG,
		useValue: config
	};
}
var SupportChatApiService = class SupportChatApiService {
	http = inject(HttpClient);
	config = inject(ESPRESSO_SUPPORT_CHAT_CONFIG);
	destroyRef = inject(DestroyRef);
	cancelRequests = new Subject();
	get base() {
		return `${this.config.apiBaseUrl.replace(/\/$/, "")}/api/v1/support-chat`;
	}
	createSession(body) {
		return this.request(this.http.post(`${this.base}/sessions`, body));
	}
	getSession(chatId, token) {
		return this.request(this.http.get(`${this.base}/sessions/${encodeURIComponent(chatId)}`, { headers: this.headers(token) }));
	}
	addContact(chatId, email, token) {
		return this.request(this.http.patch(`${this.base}/sessions/${encodeURIComponent(chatId)}/contact`, { email }, { headers: this.headers(token) }));
	}
	sendMessage(chatId, body, token) {
		return this.request(this.http.post(`${this.base}/sessions/${encodeURIComponent(chatId)}/messages`, body, { headers: this.headers(token) }));
	}
	resolution(chatId, body, token) {
		return this.request(this.http.post(`${this.base}/sessions/${encodeURIComponent(chatId)}/resolution`, body, { headers: this.headers(token) }));
	}
	feedback(chatId, body, token) {
		return this.request(this.http.post(`${this.base}/sessions/${encodeURIComponent(chatId)}/feedback`, body, { headers: this.headers(token) }));
	}
	close(chatId, token) {
		return this.request(this.http.post(`${this.base}/sessions/${encodeURIComponent(chatId)}/close`, {}, { headers: this.headers(token) }));
	}
	ticket(chatId, body, token) {
		return this.request(this.http.post(`${this.base}/sessions/${encodeURIComponent(chatId)}/tickets`, body, { headers: this.headers(token) }));
	}
	cancelPending() {
		this.cancelRequests.next();
	}
	headers(token) {
		return new HttpHeaders({ "X-Support-Session-Token": token });
	}
	request(request) {
		return request.pipe(takeUntil(this.cancelRequests), takeUntilDestroyed(this.destroyRef), catchError((e) => {
			const body = e.error ?? {};
			if (e.status === 401 || e.status === 403) return throwError(() => new SupportChatApiError(e.status, "SESSION_EXPIRED", "Your chat session has expired."));
			return throwError(() => new SupportChatApiError(e.status, body.code ?? "UNKNOWN", body.message ?? "The request could not be completed."));
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: SupportChatApiService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: SupportChatApiService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.2",
	ngImport: i0,
	type: SupportChatApiService,
	decorators: [{ type: Injectable }]
});
var EnvironmentCollectorService = class EnvironmentCollectorService {
	collect(config) {
		if (typeof navigator === "undefined" || typeof location === "undefined") return {
			platform: "unknown",
			system: "unknown",
			browser_user: "unknown",
			mobile: false,
			url: "",
			...config.product ? { product: config.product } : {}
		};
		const ua = navigator.userAgent;
		const browser_user = /Edg\//.test(ua) ? "Edge" : /Firefox\//.test(ua) ? "Firefox" : /CriOS|Chrome\//.test(ua) ? "Chrome" : /Safari\//.test(ua) ? "Safari" : /OPR\//.test(ua) ? "Opera" : "unknown";
		const system = /Windows/.test(ua) ? "Windows" : /Android/.test(ua) ? "Android" : /iPhone|iPad|iPod/.test(ua) ? "iOS" : /Mac OS|Macintosh/.test(ua) ? "macOS" : /Linux/.test(ua) ? "Linux" : "unknown";
		const nav = navigator;
		const connection = nav.connection?.type ?? nav.connection?.effectiveType;
		return {
			platform: navigator.platform || "unknown",
			system,
			browser_user,
			mobile: /Mobi|Android|iPhone|iPad/.test(ua),
			...connection ? { connection } : {},
			url: `${location.origin}${location.pathname}`,
			...config.product ? { product: config.product } : {}
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: EnvironmentCollectorService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: EnvironmentCollectorService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.2",
	ngImport: i0,
	type: EnvironmentCollectorService,
	decorators: [{ type: Injectable }]
});
var SupportChatSessionService = class SupportChatSessionService {
	config = inject(ESPRESSO_SUPPORT_CHAT_CONFIG);
	api = inject(SupportChatApiService);
	active;
	cachedEmail;
	volatileInstance = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
	key() {
		return `espresso-support-chat:v1:${encodeURIComponent(this.config.platform)}:${encodeURIComponent(this.config.instanceId ?? this.volatileInstance)}:${encodeURIComponent(this.config.userId ?? "anonymous")}`;
	}
	emailKey() {
		return `${this.key()}:contact-email`;
	}
	cacheEmail(email) {
		this.cachedEmail = email.trim();
		if (!this.active || !this.config.instanceId || typeof sessionStorage === "undefined") return;
		try {
			sessionStorage.setItem(this.emailKey(), this.cachedEmail);
		} catch {}
	}
	getCachedEmail() {
		if (this.cachedEmail) return this.cachedEmail;
		if (!this.active || !this.config.instanceId || typeof sessionStorage === "undefined") return void 0;
		try {
			this.cachedEmail = sessionStorage.getItem(this.emailKey()) ?? void 0;
		} catch {}
		return this.cachedEmail;
	}
	async get() {
		if (this.active && Date.parse(this.active.expiresAt) > Date.now()) return this.active;
		if (this.active) this.reset();
		if (!this.config.instanceId) return void 0;
		if (typeof sessionStorage === "undefined") return void 0;
		const key = this.key();
		try {
			const stored = sessionStorage.getItem(key);
			if (!stored) return void 0;
			const candidate = JSON.parse(stored);
			if (!candidate.chatId || !candidate.sessionToken || Date.parse(candidate.expiresAt) <= Date.now()) {
				this.reset();
				return;
			}
			const restored = await firstValueFrom(this.api.getSession(candidate.chatId, candidate.sessionToken));
			if (this.key() !== key) return void 0;
			this.active = {
				...candidate,
				...restored,
				sessionToken: candidate.sessionToken
			};
			return this.active;
		} catch {
			if (key === this.key()) this.reset();
			return;
		}
	}
	async create(email) {
		const storageKey = this.key();
		const body = {
			platform: this.config.platform,
			vectorStoreId: this.config.vectorStoreId,
			language: this.config.language,
			...this.config.userId ? { userId: this.config.userId } : {},
			...email || this.config.email ? { email: email || this.config.email } : {},
			...typeof location !== "undefined" ? { pageContext: { pagePath: location.pathname } } : {}
		};
		const created = await firstValueFrom(this.api.createSession(body));
		if (storageKey !== this.key()) return created;
		this.active = created;
		try {
			if (this.config.instanceId && typeof sessionStorage !== "undefined") sessionStorage.setItem(storageKey, JSON.stringify(this.active));
		} catch {}
		const contactEmail = email || this.config.email;
		if (contactEmail) this.cacheEmail(contactEmail);
		return created;
	}
	invalidate() {
		this.reset();
	}
	reset() {
		this.active = void 0;
		this.cachedEmail = void 0;
		try {
			if (typeof sessionStorage !== "undefined") {
				sessionStorage.removeItem(this.key());
				sessionStorage.removeItem(this.emailKey());
			}
		} catch {}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: SupportChatSessionService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: SupportChatSessionService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.2",
	ngImport: i0,
	type: SupportChatSessionService,
	decorators: [{ type: Injectable }]
});
const messages = {
	en: {
		title: "Support-Team",
		welcome: "Hello! How can we help?",
		ai: "AI-assisted support",
		privacy: "Privacy",
		emailLabel: "Your email address",
		emailHint: "Please provide your email so we can associate your request with you.",
		emailInvalid: "Enter a valid email address.",
		send: "Send",
		placeholder: "Write your message…",
		end: "End chat",
		close: "Close",
		resolved: "Did this solve your problem?",
		yes: "Yes",
		no: "No",
		ticket: "Create a support ticket",
		feedback: "How was your support experience?",
		comment: "Optional comment",
		continue: "Continue",
		ticketSuccess: "Ticket submitted successfully.",
		ticketUnknown: "Ticket status is unclear. Please do not submit again.",
		ticketFailed: "The ticket could not be submitted. Please try again later.",
		noKnowledge: "I could not find a reliable answer. You can create a support ticket.",
		genericError: "Something went wrong. Please try again.",
		sensitive: "Please do not include sensitive information in your message.",
		expired: "The session expired. Retry to start a new chat.",
		rateLimited: "Please wait before trying again.",
		retry: "Retry sending",
		skip: "Skip",
		loading: "One moment please…",
		sources: "Sources",
		chatEnded: "This chat has ended. If you have more questions, start a new chat.",
		newChat: "Start a new chat"
	},
	de: {
		title: "Support-Team",
		welcome: "Hallo! Wie können wir helfen?",
		ai: "KI-gestützter Support",
		privacy: "Datenschutz",
		emailLabel: "Deine E-Mail-Adresse",
		emailHint: "Bitte gib deine E-Mail-Adresse an, damit wir deine Anfrage zuordnen können.",
		emailInvalid: "Bitte gib eine gültige E-Mail-Adresse ein.",
		send: "Senden",
		placeholder: "Nachricht schreiben…",
		end: "Chat beenden",
		close: "Schließen",
		resolved: "Hat das dein Problem gelöst?",
		yes: "Ja",
		no: "Nein",
		ticket: "Ticket anlegen",
		feedback: "Wie war deine Support-Erfahrung?",
		comment: "Kommentar (optional)",
		continue: "Weiter",
		ticketSuccess: "Ticket erfolgreich übermittelt.",
		ticketUnknown: "Status derzeit unklar. Bitte nicht mehrfach senden.",
		ticketFailed: "Das Ticket konnte nicht übermittelt werden. Bitte versuche es später erneut.",
		noKnowledge: "Ich habe keine verlässliche Antwort gefunden. Du kannst ein Support-Ticket anlegen.",
		genericError: "Etwas ist schiefgelaufen. Bitte versuche es erneut.",
		sensitive: "Bitte teile keine sensiblen Daten im Nachrichtentext.",
		expired: "Die Sitzung ist abgelaufen. Mit erneutem Senden startest du einen neuen Chat.",
		rateLimited: "Bitte warte kurz, bevor du es erneut versuchst.",
		retry: "Erneut senden",
		skip: "Überspringen",
		loading: "Einen Moment bitte…",
		sources: "Quellen",
		chatEnded: "Der Chat ist beendet. Wenn du weitere Fragen hast, starte einfach einen neuen Chat.",
		newChat: "Neuen Chat starten"
	}
};
function getChatStrings(language) {
	return messages[language === "en" ? "en" : "de"];
}
var SupportChatComponent = class SupportChatComponent {
	apiBaseUrl;
	platform;
	vectorStoreId;
	language;
	userId;
	email;
	requestId;
	product;
	privacyUrl;
	supportUrl;
	instanceId;
	injectedConfig = inject(ESPRESSO_SUPPORT_CHAT_CONFIG);
	config = this.injectedConfig;
	api = inject(SupportChatApiService);
	sessions = inject(SupportChatSessionService);
	environment = inject(EnvironmentCollectorService);
	element = inject(ElementRef);
	destroyRef = inject(DestroyRef);
	changeDetector = inject(ChangeDetectorRef);
	open = false;
	closing = false;
	busy = false;
	started = false;
	closed = false;
	askEmail;
	emailDraft = "";
	emailError = "";
	input = "";
	feedbackComment = "";
	error = "";
	ticketState = "";
	messages = [];
	pendingUserMessage = "";
	pendingClientMessageId = "";
	pendingMessageAdded = false;
	lastAssistantMessageId;
	showResolution = false;
	showFeedback = false;
	identityGeneration = 0;
	emailCapturedInWidget = false;
	constructor() {
		this.askEmail = !this.config.email && !this.config.userId;
		this.emailDraft = this.config.email ?? "";
		this.destroyRef.onDestroy(() => {
			this.identityGeneration++;
			this.api.cancelPending();
		});
	}
	ngOnChanges(changes) {
		if ([
			"apiBaseUrl",
			"platform",
			"vectorStoreId",
			"userId",
			"email",
			"instanceId"
		].some((key) => !!changes[key] && !changes[key].firstChange)) {
			this.clearCapturedEmail();
			this.identityGeneration++;
			this.api.cancelPending();
			this.sessions.invalidate();
			this.messages = [];
			this.started = false;
			this.closed = false;
			this.pendingUserMessage = "";
			this.pendingClientMessageId = "";
			this.pendingMessageAdded = false;
			this.lastAssistantMessageId = void 0;
			this.showResolution = false;
			this.showFeedback = false;
			this.ticketState = "";
		}
		Object.assign(this.config, {
			...this.apiBaseUrl ? { apiBaseUrl: this.apiBaseUrl } : {},
			...this.platform ? { platform: this.platform } : {},
			...this.vectorStoreId ? { vectorStoreId: this.vectorStoreId } : {},
			...this.language ? { language: this.language } : {},
			...this.userId !== void 0 ? { userId: this.userId || null } : {},
			...this.email !== void 0 ? { email: this.email || null } : {},
			...this.requestId !== void 0 ? { requestId: this.requestId || null } : {},
			...this.product ? { product: this.product } : {},
			...this.privacyUrl ? { privacyUrl: this.privacyUrl } : {},
			...this.supportUrl ? { supportUrl: this.supportUrl } : {},
			...this.instanceId ? { instanceId: this.instanceId } : {}
		});
		this.askEmail = !this.config.email && !this.config.userId;
		this.emailDraft = this.config.email ?? "";
	}
	get strings() {
		return getChatStrings(this.config.language);
	}
	async show() {
		this.open = true;
		this.error = "";
		setTimeout(() => {
			if (this.open) this.element.nativeElement.shadowRoot?.querySelector("#support-email, #support-message")?.focus();
		}, 0);
		if (!this.started) {
			await this.restore();
			const cachedEmail = this.sessions.getCachedEmail();
			if (cachedEmail && !this.config.email) {
				this.config.email = cachedEmail;
				this.emailDraft = cachedEmail;
				this.emailCapturedInWidget = true;
			}
			this.askEmail = !this.config.email && !this.config.userId;
		}
		this.changeDetector.markForCheck();
	}
	minimize() {
		if (this.closing) return;
		this.closing = true;
	}
	onWindowAnimationEnd(event) {
		if (event.target !== event.currentTarget || event.animationName !== "et-support-chat-close") return;
		this.open = false;
		this.closing = false;
		setTimeout(() => this.element.nativeElement.shadowRoot?.querySelector(".et-launcher")?.focus(), 0);
	}
	async restore() {
		const generation = this.identityGeneration;
		const session = await this.sessions.get();
		if (generation === this.identityGeneration && session) this.started = true;
		this.changeDetector.markForCheck();
	}
	validEmail(value) {
		return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
	}
	async submitEmail() {
		if (!this.validEmail(this.emailDraft)) {
			this.emailError = this.strings.emailInvalid;
			return false;
		}
		const generation = this.identityGeneration;
		const email = this.emailDraft.trim();
		this.emailError = "";
		if (this.started) try {
			const session = await this.sessions.get();
			if (generation !== this.identityGeneration) return false;
			if (!session) throw new Error("The chat session is no longer available.");
			await firstValueFrom(this.api.addContact(session.chatId, email, session.sessionToken));
		} catch {
			if (generation === this.identityGeneration) {
				this.askEmail = true;
				this.emailError = this.strings.genericError;
			}
			return false;
		}
		this.config.email = email;
		this.emailCapturedInWidget = true;
		this.sessions.cacheEmail(email);
		this.askEmail = false;
		this.changeDetector.markForCheck();
		return generation === this.identityGeneration;
	}
	async send() {
		if (this.busy || !this.input.trim()) return;
		if (!this.config.email && !this.config.userId) {
			this.pendingUserMessage = this.input.trim();
			this.pendingClientMessageId = this.uuid();
			this.input = "";
			this.askEmail = true;
			return;
		}
		this.pendingUserMessage = this.input.trim();
		this.input = "";
		this.pendingClientMessageId = this.uuid();
		this.pendingMessageAdded = false;
		await this.sendPending();
	}
	async sendPending() {
		if (!this.pendingUserMessage || this.busy) return;
		const generation = this.identityGeneration;
		this.busy = true;
		this.error = "";
		try {
			let session = await this.sessions.get();
			if (generation !== this.identityGeneration) return;
			if (!session && this.started) {
				this.started = false;
				this.clearCapturedEmail();
				if (!this.config.email && !this.config.userId) {
					this.askEmail = true;
					return;
				}
			}
			if (!session) session = await this.sessions.create(this.config.email ?? void 0);
			if (generation !== this.identityGeneration) return;
			this.started = true;
			const text = this.pendingUserMessage;
			if (!this.pendingMessageAdded) {
				this.messages.push({
					role: "user",
					text
				});
				this.pendingMessageAdded = true;
			}
			const result = await firstValueFrom(this.api.sendMessage(session.chatId, {
				clientMessageId: this.pendingClientMessageId,
				message: text
			}, session.sessionToken));
			if (generation !== this.identityGeneration) return;
			this.pendingUserMessage = "";
			this.pendingClientMessageId = "";
			this.pendingMessageAdded = false;
			this.messages.push({
				role: "assistant",
				text: result.answer ?? result.message ?? "",
				result
			});
			this.lastAssistantMessageId = result.messageId;
			this.showResolution = true;
		} catch (e) {
			if (generation !== this.identityGeneration) return;
			if (e instanceof SupportChatApiError && e.code === "EMAIL_REQUIRED") {
				this.pendingUserMessage = this.pendingUserMessage || this.messages.at(-1)?.text || "";
				this.pendingClientMessageId ||= this.uuid();
				this.askEmail = true;
			} else if (e instanceof SupportChatApiError && e.code === "SESSION_EXPIRED") {
				this.sessions.invalidate();
				this.clearCapturedEmail();
				this.started = false;
				this.askEmail = !this.config.email && !this.config.userId;
				this.error = this.strings.expired;
			} else if (e instanceof SupportChatApiError && e.code === "NO_KNOWLEDGE_MATCH") {
				this.error = this.strings.noKnowledge;
				this.ticketState = "offered";
			} else this.error = e instanceof SupportChatApiError && e.code === "RATE_LIMITED" ? this.strings.rateLimited : this.strings.genericError;
		} finally {
			this.busy = false;
			this.changeDetector.markForCheck();
		}
	}
	async continueAfterEmail() {
		if (await this.submitEmail()) await this.sendPending();
	}
	async resolve(resolved) {
		const generation = this.identityGeneration;
		const session = await this.sessions.get();
		if (generation !== this.identityGeneration || !session) return;
		this.busy = true;
		try {
			await firstValueFrom(this.api.resolution(session.chatId, {
				resolved,
				...this.lastAssistantMessageId ? { messageId: this.lastAssistantMessageId } : {}
			}, session.sessionToken));
			if (generation !== this.identityGeneration) return;
			this.showResolution = false;
			if (!resolved) this.ticketState = "offered";
		} catch {
			if (generation === this.identityGeneration) this.error = this.strings.genericError;
		} finally {
			this.busy = false;
			this.changeDetector.markForCheck();
		}
	}
	async createTicket() {
		if (!this.config.email) {
			this.askEmail = true;
			this.ticketState = "pending";
			return;
		}
		await this.submitTicket();
	}
	async continueTicketAfterEmail() {
		if (await this.submitEmail()) await this.submitTicket();
	}
	async submitTicket() {
		const generation = this.identityGeneration;
		const session = await this.sessions.get();
		if (generation !== this.identityGeneration || !session || this.busy) return;
		this.busy = true;
		this.ticketState = "sending";
		this.error = "";
		try {
			const result = await firstValueFrom(this.api.ticket(session.chatId, {
				...this.config.requestId ? { requestId: this.config.requestId } : {},
				environment: this.environment.collect(this.config)
			}, session.sessionToken));
			if (generation !== this.identityGeneration) return;
			this.ticketState = result.status === "submitted" ? "submitted" : result.status === "unknown" ? "unknown" : "failed";
		} catch (e) {
			if (generation !== this.identityGeneration) return;
			if (e instanceof SupportChatApiError && e.code === "EMAIL_REQUIRED") {
				this.ticketState = "pending";
				this.askEmail = true;
			} else this.ticketState = e instanceof SupportChatApiError && e.code === "TICKET_UNKNOWN" ? "unknown" : "failed";
		} finally {
			this.busy = false;
			this.changeDetector.markForCheck();
		}
	}
	async end(rating) {
		if (!rating) {
			this.showFeedback = true;
			return;
		}
		const generation = this.identityGeneration;
		const session = await this.sessions.get();
		if (generation !== this.identityGeneration) return;
		if (session) {
			this.busy = true;
			try {
				await firstValueFrom(this.api.feedback(session.chatId, {
					rating,
					...this.feedbackComment.trim() ? { comment: this.feedbackComment.trim() } : {}
				}, session.sessionToken));
				if (generation !== this.identityGeneration) return;
				await firstValueFrom(this.api.close(session.chatId, session.sessionToken));
				if (generation !== this.identityGeneration) return;
			} catch {
				if (generation === this.identityGeneration) this.error = this.strings.genericError;
				return;
			} finally {
				this.busy = false;
			}
		}
		this.finishChat();
	}
	async skipFeedback() {
		const generation = this.identityGeneration;
		const session = await this.sessions.get();
		if (generation !== this.identityGeneration) return;
		if (session) {
			this.busy = true;
			try {
				await firstValueFrom(this.api.close(session.chatId, session.sessionToken));
				if (generation !== this.identityGeneration) return;
			} catch {
				if (generation === this.identityGeneration) this.error = this.strings.genericError;
				return;
			} finally {
				this.busy = false;
				this.changeDetector.markForCheck();
			}
		}
		this.finishChat();
	}
	startNewChat() {
		this.sessions.invalidate();
		this.messages = [];
		this.started = false;
		this.closed = false;
		this.showFeedback = false;
		this.showResolution = false;
		this.ticketState = "";
		this.error = "";
		this.input = "";
		this.pendingUserMessage = "";
		this.pendingClientMessageId = "";
		this.pendingMessageAdded = false;
		this.feedbackComment = "";
		this.lastAssistantMessageId = void 0;
		this.askEmail = !this.config.email && !this.config.userId;
		this.emailDraft = this.config.email ?? "";
		this.changeDetector.markForCheck();
	}
	finishChat() {
		this.sessions.invalidate();
		this.showFeedback = false;
		this.closed = true;
		this.started = false;
		this.messages = [];
		this.ticketState = "";
		this.error = "";
		this.pendingUserMessage = "";
		this.pendingClientMessageId = "";
		this.pendingMessageAdded = false;
		this.showResolution = false;
		this.lastAssistantMessageId = void 0;
		this.clearCapturedEmail();
		this.changeDetector.markForCheck();
	}
	clearCapturedEmail() {
		if (!this.emailCapturedInWidget) return;
		this.config.email = null;
		this.emailDraft = "";
		this.emailCapturedInWidget = false;
		this.askEmail = !this.config.userId;
	}
	safeLink(url) {
		try {
			return new URL(url, typeof location === "undefined" ? "https://localhost/" : location.href).protocol === "https:" || new URL(url, typeof location === "undefined" ? "https://localhost/" : location.href).protocol === "http:";
		} catch {
			return false;
		}
	}
	uuid() {
		return typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: SupportChatComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.2",
		type: SupportChatComponent,
		isStandalone: true,
		selector: "et-support-chat",
		inputs: {
			apiBaseUrl: "apiBaseUrl",
			platform: "platform",
			vectorStoreId: "vectorStoreId",
			language: "language",
			userId: "userId",
			email: "email",
			requestId: "requestId",
			product: "product",
			privacyUrl: "privacyUrl",
			supportUrl: "supportUrl",
			instanceId: "instanceId"
		},
		host: { properties: {
			"style.--et-accent": "config.theme?.accentColor || \"#28A8DF\"",
			"style.--et-z-index": "config.theme?.zIndex || 2147483000"
		} },
		providers: [
			{
				provide: ESPRESSO_SUPPORT_CHAT_CONFIG,
				useFactory: () => {
					const value = inject(ESPRESSO_SUPPORT_CHAT_CONFIG, { skipSelf: true });
					return {
						...value,
						...value.theme ? { theme: { ...value.theme } } : {}
					};
				}
			},
			SupportChatApiService,
			SupportChatSessionService,
			EnvironmentCollectorService
		],
		usesOnChanges: true,
		ngImport: i0,
		template: "@if (!open) {\n  <button type=\"button\" class=\"et-launcher\" [class.et-left]=\"config.theme?.position === 'left'\" (click)=\"show()\" [attr.aria-label]=\"strings.title\" [title]=\"strings.title\">\n    <svg class=\"et-launcher-icon\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 640\" aria-hidden=\"true\" focusable=\"false\">\n      <path d=\"M320 128C231.6 128 160 199.6 160 288L256 288L256 448L192 448C139 448 96 405 96 352L96 288C96 164.3 196.3 64 320 64C443.7 64 544 164.3 544 288L544 576.1L520 576.1C380 576 292 576 256 576L256 528C256 501.5 277.5 480 304 480L336 480C362.5 480 384 501.5 384 528L384 528L496 528.1L496 435.2C481.9 443.4 465.5 448 448 448L384 448L384 288L480 288C480 199.6 408.4 128 320 128z\" />\n    </svg>\n  </button>\n}\n\n@if (open) {\n  <section class=\"et-window\" [class.et-left]=\"config.theme?.position === 'left'\" [class.et-closing]=\"closing\" role=\"dialog\" aria-modal=\"false\" [attr.aria-label]=\"strings.title\" (keydown.escape)=\"minimize()\" (animationend)=\"onWindowAnimationEnd($event)\">\n    <header class=\"et-header et-flex et-items-center et-justify-between\">\n      <div class=\"et-brand\">\n        <svg class=\"et-brand-logo\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 59.8785 55.8311\" aria-hidden=\"true\" focusable=\"false\">\n          <path d=\"M11.7287,32.0091v17.8915C2.4852,42.9753-1.9835,30.4091.8384,19.1705c6.1795,1.0113,10.8903,6.3766,10.8903,12.8386Z\" fill=\"#f3920b\" />\n          <path d=\"M59.8782,26.1531c.0432,9.2709-4.4021,18.1732-11.712,23.7475v-17.8915c0-6.4621,4.7108-11.8273,10.8903-12.8386.5392,2.2383.8217,4.577.8217,6.9826Z\" fill=\"#445281\" />\n          <path d=\"M57.6882,14.8984c-8.128,1.6439-14.0774,8.8003-14.0767,17.2186,0,0,0,20.6727,0,20.6727-2.993,1.5393-6.2836,2.5878-9.76,3.0414V16.7203c.0041-7.4008,4.3491-13.7796,10.6561-16.7203,5.9218,3.2985,10.6095,8.5596,13.1806,14.8984Z\" fill=\"#445281\" />\n          <path d=\"M26.0434,16.7203v39.1108c-3.4765-.4536-6.767-1.5021-9.76-3.0414v-20.6727c.001-8.418-5.9489-15.5749-14.0767-17.2186C4.7778,8.5596,9.4655,3.2985,15.3873,0c6.307,2.9407,10.6521,9.3196,10.6561,16.7203Z\" fill=\"#f3920b\" />\n        </svg>\n        <strong>{{ strings.title }}</strong>\n      </div>\n      <button type=\"button\" class=\"et-close\" (click)=\"minimize()\" [attr.aria-label]=\"strings.close\">×</button>\n    </header>\n    <div class=\"et-body\" aria-live=\"polite\">\n      @if (!closed) {\n        <aside class=\"et-notices\">\n          <p class=\"et-note\">\n            <span class=\"et-note-badge\" aria-hidden=\"true\">✦</span>\n            <span>{{ strings.ai }}</span>\n            @if (config.privacyUrl && safeLink(config.privacyUrl)) {\n              <a [href]=\"config.privacyUrl\" target=\"_blank\" rel=\"noopener noreferrer\">{{ strings.privacy }}</a>\n            }\n          </p>\n          <p class=\"et-hint\"><span class=\"et-hint-icon\" aria-hidden=\"true\">i</span>{{ strings.sensitive }}</p>\n        </aside>\n        @if (!started && messages.length === 0) {\n          <div class=\"et-bubble et-assistant\">{{ strings.welcome }}</div>\n        }\n      }\n      @if (closed) {\n        <div class=\"et-chat-ended\">\n          <p role=\"status\">{{ strings.chatEnded }}</p>\n          <button type=\"button\" class=\"et-new-chat\" (click)=\"startNewChat()\">{{ strings.newChat }}</button>\n        </div>\n      }\n      @for (message of messages; track $index) {\n        <article class=\"et-bubble\" [class.et-user]=\"message.role === 'user'\" [class.et-assistant]=\"message.role === 'assistant'\">\n          <span>{{ message.text }}</span>\n          @if (message.result?.sources?.length) {\n            <ul class=\"et-sources\">\n              <li class=\"et-sources-label\">{{ strings.sources }}</li>\n              @for (source of message.result.sources; track $index) {\n                <li>\n                  @if (source.url && safeLink(source.url)) {\n                    <a [href]=\"source.url\" target=\"_blank\" rel=\"noopener noreferrer\">{{ source.title || source.url }}</a>\n                  } @else {\n                    {{ source.title || source.excerpt }}\n                  }\n                </li>\n              }\n            </ul>\n          }\n        </article>\n      }\n      @if (askEmail && !closed) {\n        <form class=\"et-email\" (ngSubmit)=\"ticketState === 'pending' ? continueTicketAfterEmail() : continueAfterEmail()\">\n          <label class=\"et-font-semibold et-mb-0\" for=\"support-email\">{{ strings.emailLabel }}</label>\n          <p class=\"et-mt-0\">\n            {{ strings.emailHint }}\n            @if (config.privacyUrl && safeLink(config.privacyUrl)) {\n              <a [href]=\"config.privacyUrl\" target=\"_blank\" rel=\"noopener noreferrer\">{{ strings.privacy }}</a>\n            }\n          </p>\n          <input id=\"support-email\" name=\"support-email\" type=\"email\" autocomplete=\"email\" required [(ngModel)]=\"emailDraft\" [attr.aria-invalid]=\"!!emailError\" />\n          @if (emailError) {\n            <span role=\"alert\">{{ emailError }}</span>\n          }\n          <button type=\"submit\" [disabled]=\"busy || !validEmail(emailDraft)\">{{ strings.continue }}</button>\n        </form>\n      }\n      @if (showResolution) {\n        <div class=\"et-action\">\n          <strong>{{ strings.resolved }}</strong>\n          <button type=\"button\" [disabled]=\"busy\" (click)=\"resolve(true)\">{{ strings.yes }}</button>\n          <button type=\"button\" [disabled]=\"busy\" (click)=\"resolve(false)\">{{ strings.no }}</button>\n        </div>\n      }\n      @if (ticketState === 'offered' || ticketState === 'pending') {\n        <div class=\"et-action\"><button type=\"button\" (click)=\"ticketState = 'pending'; createTicket()\" [disabled]=\"busy\">{{ strings.ticket }}</button></div>\n      }\n      @if (ticketState === 'submitted') {\n        <p role=\"status\">{{ strings.ticketSuccess }}</p>\n      }\n      @if (ticketState === 'unknown') {\n        <p role=\"alert\">{{ strings.ticketUnknown }}</p>\n      }\n      @if (ticketState === 'failed') {\n        <p role=\"alert\">{{ strings.ticketFailed }}</p>\n      }\n      @if (showFeedback) {\n        <div class=\"et-action\">\n          <strong>{{ strings.feedback }}</strong>\n          <label for=\"support-comment\">{{ strings.comment }}</label>\n          <textarea id=\"support-comment\" [(ngModel)]=\"feedbackComment\"></textarea>\n          <button type=\"button\" [disabled]=\"busy\" (click)=\"end('positive')\">👍</button>\n          <button type=\"button\" [disabled]=\"busy\" (click)=\"end('negative')\">👎</button>\n          <button type=\"button\" [disabled]=\"busy\" (click)=\"skipFeedback()\">{{ strings.skip }}</button>\n        </div>\n      }\n      @if (error) {\n        <p class=\"et-error\" role=\"alert\">{{ error }}</p>\n      }\n      @if (pendingUserMessage && !askEmail && !busy) {\n        <button type=\"button\" (click)=\"sendPending()\">{{ strings.retry }}</button>\n      }\n      @if (busy) {\n        <div class=\"et-loading\" role=\"status\" [attr.aria-label]=\"strings.loading\">\n          <span>{{ strings.loading }}</span>\n          <span class=\"et-loading-dots\" aria-hidden=\"true\"><i></i><i></i><i></i></span>\n        </div>\n      }\n    </div>\n    @if (!showFeedback && !closed) {\n      <form class=\"et-composer\" (ngSubmit)=\"send()\">\n        <label class=\"et-sr-only\" for=\"support-message\">{{ strings.placeholder }}</label>\n        <textarea id=\"support-message\" name=\"message\" [(ngModel)]=\"input\" [placeholder]=\"strings.placeholder\" [disabled]=\"busy || askEmail || !!pendingUserMessage\"></textarea>\n        <button type=\"submit\" [disabled]=\"busy || askEmail || !!pendingUserMessage || !input.trim()\">{{ strings.send }}</button>\n      </form>\n    }\n    @if (started && !closed && !showFeedback) {\n      <button type=\"button\" class=\"et-end\" (click)=\"end()\" [disabled]=\"busy\">{{ strings.end }}</button>\n    }\n  </section>\n}\n",
		styles: [".et-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.et-mb-0{margin-bottom:0}.et-mt-0{margin-top:0}.et-flex{display:flex}.et-items-center{align-items:center}.et-justify-between{justify-content:space-between}.et-font-semibold{font-weight:600}:host{all:initial;font-family:Arial,sans-serif;color:#202520}.et-launcher{--tw-bg-opacity:1;background-color:rgb(40 168 223/var(--tw-bg-opacity,1));position:fixed;bottom:max(1rem,env(safe-area-inset-bottom));right:1rem;z-index:var(--et-z-index);background:var(--et-accent);color:#fff;border:0;border-radius:50%;width:3.75rem;height:3.75rem;padding:0;display:grid;place-items:center;box-shadow:0 4px 18px #0003;cursor:pointer;transition:background-color .15s ease,transform .15s ease}.et-launcher:hover{--tw-bg-opacity:1;background-color:rgb(243 146 11/var(--tw-bg-opacity,1));transform:translateY(-2px)}.et-launcher:focus-visible{outline:3px solid #f3920b;outline-offset:3px}.et-launcher-icon{width:1.8rem;height:1.8rem;fill:currentColor}.et-left.et-launcher,.et-left.et-window{left:1rem;right:auto}.et-window{position:fixed;z-index:var(--et-z-index);right:1rem;bottom:max(1rem,env(safe-area-inset-bottom));width:min(380px,calc(100vw - 2rem));height:min(560px,calc(100dvh - 2rem - env(safe-area-inset-top)));display:flex;flex-direction:column;background:#fff;border-radius:1rem;box-shadow:0 8px 36px #0004;border:1px solid #d9dfda;overflow:hidden;transform-origin:bottom right;animation:et-support-chat-open .26s cubic-bezier(.2,.8,.2,1) both}.et-window.et-left{transform-origin:bottom left}.et-window.et-closing{animation:et-support-chat-close .21s cubic-bezier(.4,0,1,1) both;pointer-events:none}@keyframes et-support-chat-open{0%{opacity:0;transform:scale(.12)}to{opacity:1;transform:scale(1)}}@keyframes et-support-chat-close{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.12)}}.et-header{--tw-bg-opacity:1;background-color:rgb(40 168 223/var(--tw-bg-opacity,1));background:var(--et-accent);color:#fff;padding:.9rem 1rem;justify-content:space-between}.et-brand,.et-header{display:flex;align-items:center}.et-brand{gap:.65rem;font-size:1rem;letter-spacing:.01em}.et-brand-logo{width:2rem;height:1.9rem;flex:none}.et-close{background:transparent;color:inherit;border:0;font-size:1.5rem;cursor:pointer}.et-body{padding:1rem;overflow-y:auto;flex:1;line-height:1.55;font-size:.9rem}.et-notices{display:grid;gap:.3rem;margin:0 0 .75rem}.et-hint,.et-note{display:flex;align-items:center;gap:.4rem;font-size:.72rem;line-height:1.35;margin:0;border-radius:.35rem;padding:.35rem .5rem}.et-note{background:#f6f9fb;color:#5a6d7d;border-left:2px solid #b7d2e1}.et-note a{color:#1f7298;font-weight:600;white-space:nowrap}.et-note-badge{display:grid;place-items:center;width:1rem;height:1rem;color:#6d9bb4;flex:none}.et-hint{background:#fcfaf5;color:#75674f;border-left:2px solid #e8d5ab}.et-hint-icon{display:grid;place-items:center;width:.95rem;height:.95rem;border:1px solid #c6ae7c;border-radius:50%;color:#947a48;font-weight:700;font-size:.65rem;flex:none}.et-bubble{max-width:90%;padding:.85rem 1rem;border-radius:1rem;margin:.85rem 0;white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.65;box-shadow:0 1px 3px #13283b12}.et-assistant{background:#f5f7fa;border:1px solid #e4e9ef;border-bottom-left-radius:.3rem;color:#263445}.et-user{--tw-bg-opacity:1;background-color:rgb(236 246 253/var(--tw-bg-opacity,1));margin-left:auto;border-bottom-right-radius:.3rem;color:#18364c}.et-sources{display:grid;gap:.35rem;list-style:none;margin:.7rem 0 0;padding:.65rem 0 0;border-top:1px solid #dce3ea;font-size:.78rem;color:#526275}.et-sources-label{font-weight:700;color:#34485c}.et-loading{gap:.7rem;margin:.5rem 0 .8rem;padding:.65rem .85rem;border-radius:1rem 1rem 1rem .3rem;background:#f5f7fa;border:1px solid #e4e9ef;color:#526275;font-size:.84rem}.et-loading,.et-loading-dots{display:inline-flex;align-items:center}.et-loading-dots{gap:.22rem}.et-loading-dots i{width:.38rem;height:.38rem;border-radius:50%;background:#28a8df;animation:et-chat-typing 1.1s ease-in-out infinite}.et-loading-dots i:nth-child(2){animation-delay:.14s}.et-loading-dots i:nth-child(3){animation-delay:.28s}@keyframes et-chat-typing{0%,60%,to{opacity:.4;transform:translateY(0)}30%{opacity:1;transform:translateY(-.28rem)}}.et-action,.et-email{display:grid;gap:.55rem;border:1px solid #d9dfda;border-radius:.75rem;padding:.75rem;margin:.7rem 0}input,textarea{font:inherit;border:1px solid #9aa49d;border-radius:.4rem;padding:.55rem;width:100%;box-sizing:border-box}button{font:inherit}.et-action button,.et-composer button,.et-email button,.et-new-chat{--tw-bg-opacity:1;background-color:rgb(40 168 223/var(--tw-bg-opacity,1));border:0;border-radius:.45rem;padding:.55rem .8rem;background:var(--et-accent);color:#fff;cursor:pointer}.et-chat-ended{display:grid;gap:.6rem;max-width:22rem;margin:2rem auto}.et-chat-ended p[role=status]{margin:0}.et-new-chat{justify-self:start;font-weight:600}button:disabled{opacity:.55;cursor:not-allowed}.et-composer{display:flex;gap:.4rem;padding:.65rem;border-top:1px solid #ddd;align-items:end}.et-composer textarea{resize:vertical;min-height:2.6rem;max-height:6rem}.et-end{align-self:flex-start;margin:0 .7rem .6rem;border:0;background:transparent;text-decoration:underline;cursor:pointer}.et-error,p[role=alert]{background-color:rgb(227 52 47/var(--tw-bg-opacity,1))}.et-error,p[role=alert],p[role=status]{border-radius:.5rem;--tw-bg-opacity:1;font-size:.875rem;line-height:1.25rem;font-weight:600;--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity,1));margin:.6rem 0;padding:.7rem .85rem;line-height:1.45}p[role=status]{background-color:rgb(56 193 114/var(--tw-bg-opacity,1))}.et-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@media(max-width:600px){.et-window{inset:env(safe-area-inset-top) 0 env(safe-area-inset-bottom);width:100%;height:auto;border-radius:0}.et-launcher{right:1rem}}@media(prefers-reduced-motion:reduce){*,:after,:before{scroll-behavior:auto!important;animation-duration:.01ms!important}}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.RequiredValidator,
				selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
				inputs: ["required"]
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			}
		],
		encapsulation: i0.ViewEncapsulation.ShadowDom
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.2",
	ngImport: i0,
	type: SupportChatComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "et-support-chat",
			standalone: true,
			imports: [FormsModule],
			encapsulation: ViewEncapsulation.ShadowDom,
			providers: [
				{
					provide: ESPRESSO_SUPPORT_CHAT_CONFIG,
					useFactory: () => {
						const value = inject(ESPRESSO_SUPPORT_CHAT_CONFIG, { skipSelf: true });
						return {
							...value,
							...value.theme ? { theme: { ...value.theme } } : {}
						};
					}
				},
				SupportChatApiService,
				SupportChatSessionService,
				EnvironmentCollectorService
			],
			host: {
				"[style.--et-accent]": "config.theme?.accentColor || \"#28A8DF\"",
				"[style.--et-z-index]": "config.theme?.zIndex || 2147483000"
			},
			template: "@if (!open) {\n  <button type=\"button\" class=\"et-launcher\" [class.et-left]=\"config.theme?.position === 'left'\" (click)=\"show()\" [attr.aria-label]=\"strings.title\" [title]=\"strings.title\">\n    <svg class=\"et-launcher-icon\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 640\" aria-hidden=\"true\" focusable=\"false\">\n      <path d=\"M320 128C231.6 128 160 199.6 160 288L256 288L256 448L192 448C139 448 96 405 96 352L96 288C96 164.3 196.3 64 320 64C443.7 64 544 164.3 544 288L544 576.1L520 576.1C380 576 292 576 256 576L256 528C256 501.5 277.5 480 304 480L336 480C362.5 480 384 501.5 384 528L384 528L496 528.1L496 435.2C481.9 443.4 465.5 448 448 448L384 448L384 288L480 288C480 199.6 408.4 128 320 128z\" />\n    </svg>\n  </button>\n}\n\n@if (open) {\n  <section class=\"et-window\" [class.et-left]=\"config.theme?.position === 'left'\" [class.et-closing]=\"closing\" role=\"dialog\" aria-modal=\"false\" [attr.aria-label]=\"strings.title\" (keydown.escape)=\"minimize()\" (animationend)=\"onWindowAnimationEnd($event)\">\n    <header class=\"et-header et-flex et-items-center et-justify-between\">\n      <div class=\"et-brand\">\n        <svg class=\"et-brand-logo\" xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 59.8785 55.8311\" aria-hidden=\"true\" focusable=\"false\">\n          <path d=\"M11.7287,32.0091v17.8915C2.4852,42.9753-1.9835,30.4091.8384,19.1705c6.1795,1.0113,10.8903,6.3766,10.8903,12.8386Z\" fill=\"#f3920b\" />\n          <path d=\"M59.8782,26.1531c.0432,9.2709-4.4021,18.1732-11.712,23.7475v-17.8915c0-6.4621,4.7108-11.8273,10.8903-12.8386.5392,2.2383.8217,4.577.8217,6.9826Z\" fill=\"#445281\" />\n          <path d=\"M57.6882,14.8984c-8.128,1.6439-14.0774,8.8003-14.0767,17.2186,0,0,0,20.6727,0,20.6727-2.993,1.5393-6.2836,2.5878-9.76,3.0414V16.7203c.0041-7.4008,4.3491-13.7796,10.6561-16.7203,5.9218,3.2985,10.6095,8.5596,13.1806,14.8984Z\" fill=\"#445281\" />\n          <path d=\"M26.0434,16.7203v39.1108c-3.4765-.4536-6.767-1.5021-9.76-3.0414v-20.6727c.001-8.418-5.9489-15.5749-14.0767-17.2186C4.7778,8.5596,9.4655,3.2985,15.3873,0c6.307,2.9407,10.6521,9.3196,10.6561,16.7203Z\" fill=\"#f3920b\" />\n        </svg>\n        <strong>{{ strings.title }}</strong>\n      </div>\n      <button type=\"button\" class=\"et-close\" (click)=\"minimize()\" [attr.aria-label]=\"strings.close\">×</button>\n    </header>\n    <div class=\"et-body\" aria-live=\"polite\">\n      @if (!closed) {\n        <aside class=\"et-notices\">\n          <p class=\"et-note\">\n            <span class=\"et-note-badge\" aria-hidden=\"true\">✦</span>\n            <span>{{ strings.ai }}</span>\n            @if (config.privacyUrl && safeLink(config.privacyUrl)) {\n              <a [href]=\"config.privacyUrl\" target=\"_blank\" rel=\"noopener noreferrer\">{{ strings.privacy }}</a>\n            }\n          </p>\n          <p class=\"et-hint\"><span class=\"et-hint-icon\" aria-hidden=\"true\">i</span>{{ strings.sensitive }}</p>\n        </aside>\n        @if (!started && messages.length === 0) {\n          <div class=\"et-bubble et-assistant\">{{ strings.welcome }}</div>\n        }\n      }\n      @if (closed) {\n        <div class=\"et-chat-ended\">\n          <p role=\"status\">{{ strings.chatEnded }}</p>\n          <button type=\"button\" class=\"et-new-chat\" (click)=\"startNewChat()\">{{ strings.newChat }}</button>\n        </div>\n      }\n      @for (message of messages; track $index) {\n        <article class=\"et-bubble\" [class.et-user]=\"message.role === 'user'\" [class.et-assistant]=\"message.role === 'assistant'\">\n          <span>{{ message.text }}</span>\n          @if (message.result?.sources?.length) {\n            <ul class=\"et-sources\">\n              <li class=\"et-sources-label\">{{ strings.sources }}</li>\n              @for (source of message.result.sources; track $index) {\n                <li>\n                  @if (source.url && safeLink(source.url)) {\n                    <a [href]=\"source.url\" target=\"_blank\" rel=\"noopener noreferrer\">{{ source.title || source.url }}</a>\n                  } @else {\n                    {{ source.title || source.excerpt }}\n                  }\n                </li>\n              }\n            </ul>\n          }\n        </article>\n      }\n      @if (askEmail && !closed) {\n        <form class=\"et-email\" (ngSubmit)=\"ticketState === 'pending' ? continueTicketAfterEmail() : continueAfterEmail()\">\n          <label class=\"et-font-semibold et-mb-0\" for=\"support-email\">{{ strings.emailLabel }}</label>\n          <p class=\"et-mt-0\">\n            {{ strings.emailHint }}\n            @if (config.privacyUrl && safeLink(config.privacyUrl)) {\n              <a [href]=\"config.privacyUrl\" target=\"_blank\" rel=\"noopener noreferrer\">{{ strings.privacy }}</a>\n            }\n          </p>\n          <input id=\"support-email\" name=\"support-email\" type=\"email\" autocomplete=\"email\" required [(ngModel)]=\"emailDraft\" [attr.aria-invalid]=\"!!emailError\" />\n          @if (emailError) {\n            <span role=\"alert\">{{ emailError }}</span>\n          }\n          <button type=\"submit\" [disabled]=\"busy || !validEmail(emailDraft)\">{{ strings.continue }}</button>\n        </form>\n      }\n      @if (showResolution) {\n        <div class=\"et-action\">\n          <strong>{{ strings.resolved }}</strong>\n          <button type=\"button\" [disabled]=\"busy\" (click)=\"resolve(true)\">{{ strings.yes }}</button>\n          <button type=\"button\" [disabled]=\"busy\" (click)=\"resolve(false)\">{{ strings.no }}</button>\n        </div>\n      }\n      @if (ticketState === 'offered' || ticketState === 'pending') {\n        <div class=\"et-action\"><button type=\"button\" (click)=\"ticketState = 'pending'; createTicket()\" [disabled]=\"busy\">{{ strings.ticket }}</button></div>\n      }\n      @if (ticketState === 'submitted') {\n        <p role=\"status\">{{ strings.ticketSuccess }}</p>\n      }\n      @if (ticketState === 'unknown') {\n        <p role=\"alert\">{{ strings.ticketUnknown }}</p>\n      }\n      @if (ticketState === 'failed') {\n        <p role=\"alert\">{{ strings.ticketFailed }}</p>\n      }\n      @if (showFeedback) {\n        <div class=\"et-action\">\n          <strong>{{ strings.feedback }}</strong>\n          <label for=\"support-comment\">{{ strings.comment }}</label>\n          <textarea id=\"support-comment\" [(ngModel)]=\"feedbackComment\"></textarea>\n          <button type=\"button\" [disabled]=\"busy\" (click)=\"end('positive')\">👍</button>\n          <button type=\"button\" [disabled]=\"busy\" (click)=\"end('negative')\">👎</button>\n          <button type=\"button\" [disabled]=\"busy\" (click)=\"skipFeedback()\">{{ strings.skip }}</button>\n        </div>\n      }\n      @if (error) {\n        <p class=\"et-error\" role=\"alert\">{{ error }}</p>\n      }\n      @if (pendingUserMessage && !askEmail && !busy) {\n        <button type=\"button\" (click)=\"sendPending()\">{{ strings.retry }}</button>\n      }\n      @if (busy) {\n        <div class=\"et-loading\" role=\"status\" [attr.aria-label]=\"strings.loading\">\n          <span>{{ strings.loading }}</span>\n          <span class=\"et-loading-dots\" aria-hidden=\"true\"><i></i><i></i><i></i></span>\n        </div>\n      }\n    </div>\n    @if (!showFeedback && !closed) {\n      <form class=\"et-composer\" (ngSubmit)=\"send()\">\n        <label class=\"et-sr-only\" for=\"support-message\">{{ strings.placeholder }}</label>\n        <textarea id=\"support-message\" name=\"message\" [(ngModel)]=\"input\" [placeholder]=\"strings.placeholder\" [disabled]=\"busy || askEmail || !!pendingUserMessage\"></textarea>\n        <button type=\"submit\" [disabled]=\"busy || askEmail || !!pendingUserMessage || !input.trim()\">{{ strings.send }}</button>\n      </form>\n    }\n    @if (started && !closed && !showFeedback) {\n      <button type=\"button\" class=\"et-end\" (click)=\"end()\" [disabled]=\"busy\">{{ strings.end }}</button>\n    }\n  </section>\n}\n",
			styles: [".et-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.et-mb-0{margin-bottom:0}.et-mt-0{margin-top:0}.et-flex{display:flex}.et-items-center{align-items:center}.et-justify-between{justify-content:space-between}.et-font-semibold{font-weight:600}:host{all:initial;font-family:Arial,sans-serif;color:#202520}.et-launcher{--tw-bg-opacity:1;background-color:rgb(40 168 223/var(--tw-bg-opacity,1));position:fixed;bottom:max(1rem,env(safe-area-inset-bottom));right:1rem;z-index:var(--et-z-index);background:var(--et-accent);color:#fff;border:0;border-radius:50%;width:3.75rem;height:3.75rem;padding:0;display:grid;place-items:center;box-shadow:0 4px 18px #0003;cursor:pointer;transition:background-color .15s ease,transform .15s ease}.et-launcher:hover{--tw-bg-opacity:1;background-color:rgb(243 146 11/var(--tw-bg-opacity,1));transform:translateY(-2px)}.et-launcher:focus-visible{outline:3px solid #f3920b;outline-offset:3px}.et-launcher-icon{width:1.8rem;height:1.8rem;fill:currentColor}.et-left.et-launcher,.et-left.et-window{left:1rem;right:auto}.et-window{position:fixed;z-index:var(--et-z-index);right:1rem;bottom:max(1rem,env(safe-area-inset-bottom));width:min(380px,calc(100vw - 2rem));height:min(560px,calc(100dvh - 2rem - env(safe-area-inset-top)));display:flex;flex-direction:column;background:#fff;border-radius:1rem;box-shadow:0 8px 36px #0004;border:1px solid #d9dfda;overflow:hidden;transform-origin:bottom right;animation:et-support-chat-open .26s cubic-bezier(.2,.8,.2,1) both}.et-window.et-left{transform-origin:bottom left}.et-window.et-closing{animation:et-support-chat-close .21s cubic-bezier(.4,0,1,1) both;pointer-events:none}@keyframes et-support-chat-open{0%{opacity:0;transform:scale(.12)}to{opacity:1;transform:scale(1)}}@keyframes et-support-chat-close{0%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.12)}}.et-header{--tw-bg-opacity:1;background-color:rgb(40 168 223/var(--tw-bg-opacity,1));background:var(--et-accent);color:#fff;padding:.9rem 1rem;justify-content:space-between}.et-brand,.et-header{display:flex;align-items:center}.et-brand{gap:.65rem;font-size:1rem;letter-spacing:.01em}.et-brand-logo{width:2rem;height:1.9rem;flex:none}.et-close{background:transparent;color:inherit;border:0;font-size:1.5rem;cursor:pointer}.et-body{padding:1rem;overflow-y:auto;flex:1;line-height:1.55;font-size:.9rem}.et-notices{display:grid;gap:.3rem;margin:0 0 .75rem}.et-hint,.et-note{display:flex;align-items:center;gap:.4rem;font-size:.72rem;line-height:1.35;margin:0;border-radius:.35rem;padding:.35rem .5rem}.et-note{background:#f6f9fb;color:#5a6d7d;border-left:2px solid #b7d2e1}.et-note a{color:#1f7298;font-weight:600;white-space:nowrap}.et-note-badge{display:grid;place-items:center;width:1rem;height:1rem;color:#6d9bb4;flex:none}.et-hint{background:#fcfaf5;color:#75674f;border-left:2px solid #e8d5ab}.et-hint-icon{display:grid;place-items:center;width:.95rem;height:.95rem;border:1px solid #c6ae7c;border-radius:50%;color:#947a48;font-weight:700;font-size:.65rem;flex:none}.et-bubble{max-width:90%;padding:.85rem 1rem;border-radius:1rem;margin:.85rem 0;white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.65;box-shadow:0 1px 3px #13283b12}.et-assistant{background:#f5f7fa;border:1px solid #e4e9ef;border-bottom-left-radius:.3rem;color:#263445}.et-user{--tw-bg-opacity:1;background-color:rgb(236 246 253/var(--tw-bg-opacity,1));margin-left:auto;border-bottom-right-radius:.3rem;color:#18364c}.et-sources{display:grid;gap:.35rem;list-style:none;margin:.7rem 0 0;padding:.65rem 0 0;border-top:1px solid #dce3ea;font-size:.78rem;color:#526275}.et-sources-label{font-weight:700;color:#34485c}.et-loading{gap:.7rem;margin:.5rem 0 .8rem;padding:.65rem .85rem;border-radius:1rem 1rem 1rem .3rem;background:#f5f7fa;border:1px solid #e4e9ef;color:#526275;font-size:.84rem}.et-loading,.et-loading-dots{display:inline-flex;align-items:center}.et-loading-dots{gap:.22rem}.et-loading-dots i{width:.38rem;height:.38rem;border-radius:50%;background:#28a8df;animation:et-chat-typing 1.1s ease-in-out infinite}.et-loading-dots i:nth-child(2){animation-delay:.14s}.et-loading-dots i:nth-child(3){animation-delay:.28s}@keyframes et-chat-typing{0%,60%,to{opacity:.4;transform:translateY(0)}30%{opacity:1;transform:translateY(-.28rem)}}.et-action,.et-email{display:grid;gap:.55rem;border:1px solid #d9dfda;border-radius:.75rem;padding:.75rem;margin:.7rem 0}input,textarea{font:inherit;border:1px solid #9aa49d;border-radius:.4rem;padding:.55rem;width:100%;box-sizing:border-box}button{font:inherit}.et-action button,.et-composer button,.et-email button,.et-new-chat{--tw-bg-opacity:1;background-color:rgb(40 168 223/var(--tw-bg-opacity,1));border:0;border-radius:.45rem;padding:.55rem .8rem;background:var(--et-accent);color:#fff;cursor:pointer}.et-chat-ended{display:grid;gap:.6rem;max-width:22rem;margin:2rem auto}.et-chat-ended p[role=status]{margin:0}.et-new-chat{justify-self:start;font-weight:600}button:disabled{opacity:.55;cursor:not-allowed}.et-composer{display:flex;gap:.4rem;padding:.65rem;border-top:1px solid #ddd;align-items:end}.et-composer textarea{resize:vertical;min-height:2.6rem;max-height:6rem}.et-end{align-self:flex-start;margin:0 .7rem .6rem;border:0;background:transparent;text-decoration:underline;cursor:pointer}.et-error,p[role=alert]{background-color:rgb(227 52 47/var(--tw-bg-opacity,1))}.et-error,p[role=alert],p[role=status]{border-radius:.5rem;--tw-bg-opacity:1;font-size:.875rem;line-height:1.25rem;font-weight:600;--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity,1));margin:.6rem 0;padding:.7rem .85rem;line-height:1.45}p[role=status]{background-color:rgb(56 193 114/var(--tw-bg-opacity,1))}.et-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@media(max-width:600px){.et-window{inset:env(safe-area-inset-top) 0 env(safe-area-inset-bottom);width:100%;height:auto;border-radius:0}.et-launcher{right:1rem}}@media(prefers-reduced-motion:reduce){*,:after,:before{scroll-behavior:auto!important;animation-duration:.01ms!important}}\n"]
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		apiBaseUrl: [{ type: Input }],
		platform: [{ type: Input }],
		vectorStoreId: [{ type: Input }],
		language: [{ type: Input }],
		userId: [{ type: Input }],
		email: [{ type: Input }],
		requestId: [{ type: Input }],
		product: [{ type: Input }],
		privacyUrl: [{ type: Input }],
		supportUrl: [{ type: Input }],
		instanceId: [{ type: Input }]
	}
});
var SupportChatModule = class SupportChatModule {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: SupportChatModule,
		deps: [],
		target: i0.ɵɵFactoryTarget.NgModule
	});
	static ɵmod = i0.ɵɵngDeclareNgModule({
		minVersion: "14.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: SupportChatModule,
		imports: [
			CommonModule,
			HttpClientModule,
			FormsModule,
			SupportChatComponent
		],
		exports: [SupportChatComponent]
	});
	static ɵinj = i0.ɵɵngDeclareInjector({
		minVersion: "12.0.0",
		version: "22.2.2",
		ngImport: i0,
		type: SupportChatModule,
		imports: [
			CommonModule,
			HttpClientModule,
			FormsModule,
			SupportChatComponent
		]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.2",
	ngImport: i0,
	type: SupportChatModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				CommonModule,
				HttpClientModule,
				FormsModule,
				SupportChatComponent
			],
			exports: [SupportChatComponent]
		}]
	}]
});
export { ESPRESSO_SUPPORT_CHAT_CONFIG, SupportChatApiError, SupportChatApiService, SupportChatComponent, SupportChatModule, getChatStrings, provideEspressoSupportChat };

//# sourceMappingURL=espresso-tutorials-support-chat.mjs.map